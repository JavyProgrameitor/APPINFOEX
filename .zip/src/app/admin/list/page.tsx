// app/admin/list/page.tsx
import { Suspense } from 'react'
import AdminListBFPageClient from './AdminListBFPageClient'

type SearchParams = {
  id?: string | string[]
}

type PageProps = {
  searchParams: Promise<SearchParams>
}

export default async function Page({ searchParams }: PageProps) {
  const params = await searchParams

  const idParam = Array.isArray(params.id) ? params.id[0] : params.id

  return (
    <Suspense
      fallback={
        <main className="p-4 md:p-6 max-w-3xl mx-auto">
          <p className="text-sm text-muted-foreground">Cargando…</p>
        </main>
      }
    >
      <AdminListBFPageClient userId={idParam} />
    </Suspense>
  )
}
