// src/app/bf/page.tsx
'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardTitle } from '@/components/ui/Card'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { useToast } from '@/components/ui/Use-toast'
import { getSupabaseBrowser } from '@/server/client'
import { PanelBottom } from 'lucide-react'

export default function BFHome() {
  const router = useRouter()
  const { toast } = useToast()

  const [loadingPage, setLoadingPage] = useState(true)
  const [saving, setSaving] = useState(false)

  const [newPass, setNewPass] = useState('')
  const [newPass2, setNewPass2] = useState('')
  const [error, setError] = useState<string | null>(null)

  // Comprobar que el usuario está logueado y tiene rol "bf"
  useEffect(() => {
    ;(async () => {
      try {
        const res = await fetch('/supabase/me', { credentials: 'include' })
        if (res.status !== 200) {
          router.replace('/')
          return
        }

        const me = await res.json()

        const allowedRoles = ['bf', 'jr'] as const
        if (!allowedRoles.includes(me.rol)) {
          // Si no es bombero forestal ni jefe de retén, lo mandamos fuera
          router.replace('/')
          return
        }
      } catch (e) {
        router.replace('/')
        return
      } finally {
        setLoadingPage(false)
      }
    })()
  }, [router])

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)

    // Validaciones básicas
    if (newPass.length < 8) {
      setError('La contraseña debe tener al menos 8 caracteres.')
      return
    }
    if (newPass !== newPass2) {
      setError('Las contraseñas no coinciden.')
      return
    }

    setSaving(true)
    try {
      const supabase = getSupabaseBrowser()
      const { error } = await supabase.auth.updateUser({ password: newPass })

      if (error) {
        setError(error.message)
        return
      }

      setNewPass('')
      setNewPass2('')

      toast({
        title: 'Contraseña actualizada',
        description: 'A partir de ahora deberás usar la nueva contraseña para iniciar sesión.',
      })
    } catch {
      setError('No se pudo cambiar la contraseña. Inténtalo de nuevo.')
    } finally {
      setSaving(false)
    }
  }

  if (loadingPage) {
    return (
      <div className="p-4">
        <p>Cargando…</p>
      </div>
    )
  }

  return (
    <div className="flex items-center justify-center p-10">
      <div>
        <div className="flex items-center justify-center">
          <PanelBottom></PanelBottom>
          <CardTitle className="text-xl font-black text-animate flex items-center gap-3 p-4">
            BIENVENIDO B.F. DE EXTREMADURA
          </CardTitle>
        </div>
        <Card className="rounded-2xl shadow-accent">
          <CardTitle className="text-lg text-center">Cambiar contraseña o continuar :</CardTitle>
          <CardContent className="flex items-center justify-center">
            <form onSubmit={onSubmit}>
              <label className="text-sm font-bold">Nueva contraseña</label>
              <div>
                <Input
                  type="password"
                  value={newPass}
                  placeholder="    ********   "
                  onChange={(e) => setNewPass(e.target.value)}
                  required
                />
              </div>
              <label className="text-sm font-bold">Repite la nueva contraseña</label>
              <div>
                <Input
                  type="password"
                  value={newPass2}
                  placeholder="    ********   "
                  onChange={(e) => setNewPass2(e.target.value)}
                  required
                />
              </div>
              {error && <p className="text-sm text-red-500">{error}</p>}
              <div className="flex items-center justify-center gap-3 m-3">
                <Button variant="ghost" type="submit" disabled={saving}>
                  {saving ? 'Guardando...' : 'Actualizar'}
                </Button>
                <Button variant="ghost" onClick={() => router.push('/bf/list')}>
                  Continuar
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
