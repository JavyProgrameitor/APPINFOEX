export default function AdminDelete() {
  return <div className="p-4">Panel de eliminaciones de usuarios por el adminstrador</div>
}
