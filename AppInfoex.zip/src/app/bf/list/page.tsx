export default function BFHome() {
  return <div className="p-4">Bienvenido al panel de Bomberos Forestales</div>
}
